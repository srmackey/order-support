# Escalation Guidelines

## When to Escalate to a Human
Escalate immediately if any of the following are true:
- Customer expresses strong frustration, anger, or uses language indicating distress
- Request involves a refund or compensation above $150
- Issue is not covered by standard policy and requires an exception
- Customer explicitly asks to speak with a person
- Multiple failed attempts to resolve the same issue
- Suspected fraud or chargeback risk
- Legal, safety, or compliance concern

## Information to Include in Escalation
- Order number (if available)
- Summary of the conversation
- Relevant policy sections already retrieved
- Any tool results (order status, eligibility checks)
- Recommended next action

## Response to Customer
Inform the customer that a specialist will review the case and follow up within one business day. Do not promise a specific outcome.
